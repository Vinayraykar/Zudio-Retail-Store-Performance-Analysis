SELECT * FROM zudio_database.zudio;


use zudio_database;

/* Project Title: Retail Store Performance and Customer Behaviour Analysis for Zudio */


# Q1) What is the monthly trend of product sales?

select `Clothing Type`,
month(`Order Date`) as "Monthly_Trend",
SUM(`Price` * `Quantity`) as "Revenue" from zudio
GROUP BY `Clothing Type`,month(`Order Date`)
ORDER BY "Revenue" DESC;


#Q2) Which products have the highest revenue per unit sold?

select `Clothing Type` as Product,
SUM(Quantity) as "Unit",
SUM(Price * Quantity) as "Revenue",
ROUND(SUM(Price * Quantity) / SUM(Quantity),2) as "Revenue_Per_unit"

FROM zudio
GROUP BY Product
ORDER BY "Revenue_Per_unit" DESC;


#Q3) Are high-priced products sold in higher or lower quantities?

select `Clothing Type` as Product,
AVG(`Price`) as AVG_Price,
SUM(Quantity) as Total_Quantity,
ROUND(Avg(Quantity)) as AVG_Quantity

FROM zudio
GROUP BY Product
ORDER BY AVG_Price DESC;


# Q4. Who are the top 10 most valuable customers by total spend?

select * from zudio;

select `Customer ID`,
SUM(Price * Quantity) as Total_Spends FROM zudio
Group BY `Customer ID`
ORDER BY Total_Spends DESC
LIMIT 10;

#Q5. What is the average spend per customer by region?

select `Customer ID`, Round(AVG(Price * Quantity),2) as Avg_spends, City FROM zudio
GROUP BY city, `Customer ID`
ORDER BY AVG_spends DESC;



# Q6. Are there seasonal patterns in customer purchasing behaviour?

select 
		MONTHNAME(`order date`) as Month,
        COUNT(`order ID`) as Total_purchased from zudio
        
GROUP BY  MONTHNAME(`order date`)
ORDER BY Total_purchased DESC;


# Q7. How does customer location impact purchase volume?

select * from zudio;

select
	city as Location,
    COunt(`order ID`) as Purchase_Volume
FRom zudio
GROUP BY city
ORDER BY Purchase_Volume DESC;

#Q8. Do stores with more security features perform better in terms of sales?

select
	`Security Features`,
    SUM(Price * Quantity) as Total_Sales
FROM zudio
GROUP BY `Security Features`
ORDER BY Total_Sales DESC;

#Q9. Is there a pattern between operating hours and number of daily orders?

SELECT 
	`Operating Hours` as Operating_Hours,
    AVG(Daily_orders) as AVG_Daily_Orders
FROM (
	select
		`Operating Hours`,
		DATE(`Order Date`) as Dates,
		COUNT(`Order ID`) as Daily_orders
		FROM zudio
		GROUP BY `Operating Hours`, Dates) as SUB
GROUP BY Operating_Hours
Order BY Avg_Daily_Orders DESC;
        
    

